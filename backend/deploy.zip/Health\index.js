module.exports = function (context, req) {
  context.res = {
    // status: 200 is the default
    body: "Hello from Azure Functions with simple response"
  };
  context.done();
};
