const { app } = require('@azure/functions');

// Register Health function
app.http('Health', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: 'health',
  handler: async (request, context) => {
    return {
      status: 200,
      body: JSON.stringify({ status: 'ok', time: new Date().toISOString() })
    };
  }
});
